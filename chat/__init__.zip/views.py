from django.shortcuts import render

# Create your views here.
from rest_framework import generics, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import Message
from .serializers import MessageSerializer, MessageListSerializer
from users.models import User

class SendMessageView(generics.CreateAPIView):
    """发送消息"""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageSerializer
    
    def perform_create(self, serializer):
        """自动关联当前用户为发送者"""
        serializer.save(sender=self.request.user)


class GetConversationView(generics.ListAPIView):
    """获取与某个用户的聊天记录"""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageListSerializer
    
    def get_queryset(self):
        """获取当前用户与某个用户之间的所有消息"""
        user = self.request.user
        other_user_id = self.kwargs.get('user_id')
        
        # 获取发送给该用户和从该用户收到的所有消息
        messages = Message.objects.filter(
            Q(sender=user, receiver_id=other_user_id) |
            Q(sender_id=other_user_id, receiver=user)
        ).order_by('-created_at')
        
        return messages
    
    def list(self, request, *args, **kwargs):
        """获取聊天记录后，自动标记接收者的消息为已读"""
        response = super().list(request, *args, **kwargs)
        
        # 标记当前用户收到的所有消息为已读
        other_user_id = self.kwargs.get('user_id')
        Message.objects.filter(
            receiver=request.user,
            sender_id=other_user_id,
            is_read=False
        ).update(is_read=True)
        
        return response


class InboxView(generics.ListAPIView):
    """获取收件箱（所有接收到的消息）"""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageListSerializer
    
    def get_queryset(self):
        """只返回当前用户接收到的消息"""
        return Message.objects.filter(receiver=self.request.user).order_by('-created_at')


class SentBoxView(generics.ListAPIView):
    """获取发件箱（所有发送的消息）"""
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = MessageListSerializer
    
    def get_queryset(self):
        """只返回当前用户发送的消息"""
        return Message.objects.filter(sender=self.request.user).order_by('-created_at')


class UnreadCountView(APIView):
    """获取未读消息数"""
    permission_classes = [permissions.IsAuthenticated]
    
    def get(self, request):
        """返回当前用户的未读消息数"""
        unread_count = Message.objects.filter(
            receiver=request.user,
            is_read=False
        ).count()
        
        return Response({
            'unread_count': unread_count
        })


class MarkMessagesAsReadView(APIView):
    """标记与某个用户的消息为已读"""
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request, user_id):
        """标记从指定用户收到的所有消息为已读"""
        Message.objects.filter(
            receiver=request.user,
            sender_id=user_id,
            is_read=False
        ).update(is_read=True)
        
        return Response({
            'message': '已标记为已读'
        }, status=status.HTTP_200_OK)