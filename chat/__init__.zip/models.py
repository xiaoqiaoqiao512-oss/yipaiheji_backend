from django.db import models
from users.models import User

class  Message(models.Model):
    """邮件式聊天模块"""
    sender = models.ForeignKey(
        User,
        on_delete=models.CASCADE, #using CASCADE to delete messages if user is deleted
        related_name='sent_messages',
        verbose_name='发送者'
    )

    receiver = models.ForeignKey(
        User,
        on_delete=models.CASCADE, #using CASCADE to delete messages if user is deleted
        related_name='received_messages',
        verbose_name='接收者'
    )
    #which means message content
    content = models.TextField(verbose_name='消息内容')

    #message status
    is_read = models.BooleanField(verbose_name='是否已读', default=False)

    #timestamp
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='发送时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'chat_message'
        verbose_name = '聊天消息'
        verbose_name_plural = verbose_name
        ordering = ['-created_at'] #default ordering by created_at descending
        indexes = [
            models.Index(fields=['receiver', 'is_read']),
        ]
    
    def __str__(self):
        return f"{self.sender.username} -> {self.receiver.username}: {self.content[:50]}"
    
    def mark_as_read(self):
        """Mark the message as read"""
        if not self.is_read:
            self.is_read = True
            self.save(update_fields=['is_read'])
# Create your models here.
