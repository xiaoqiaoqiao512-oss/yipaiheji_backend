from django.urls import path
from . import views

urlpatterns = [
    # 发送消息
    path('send/', views.SendMessageView.as_view(), name='send-message'),
    
    # 获取与某个用户的聊天记录
    path('conversation/<int:user_id>/', views.GetConversationView.as_view(), name='get-conversation'),
    
    # 收件箱（接收的消息）
    path('inbox/', views.InboxView.as_view(), name='inbox'),
    
    # 发件箱（发送的消息）
    path('sent/', views.SentBoxView.as_view(), name='sent-box'),
    
    # 未读消息数
    path('unread-count/', views.UnreadCountView.as_view(), name='unread-count'),
    
    # 标记为已读
    path('mark-read/<int:user_id>/', views.MarkMessagesAsReadView.as_view(), name='mark-as-read'),
]