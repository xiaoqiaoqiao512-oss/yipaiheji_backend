from rest_framework import serializers
from .models import Message
from users.models import User

class MessageSerializer(serializers.ModelSerializer):
    """消息序列化器"""
    sender_username = serializers.CharField(source='sender.username', read_only=True)
    sender_avatar = serializers.ImageField(source='sender.avatar', read_only=True)
    receiver_username = serializers.CharField(source='receiver.username', read_only=True)
    
    # 时间格式化
    created_at = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S", read_only=True)
    
    class Meta:
        model = Message
        fields = [
            'id', 'sender', 'sender_username', 'sender_avatar',
            'receiver', 'receiver_username',
            'content', 'is_read', 'created_at', 'updated_at'
        ]
        read_only_fields = ['sender', 'sender_username', 'sender_avatar', 'created_at', 'updated_at']
    
    def create(self, validated_data):
        """创建消息时，自动关联当前登录用户为发送者"""
        user = self.context['request'].user
        validated_data['sender'] = user
        return super().create(validated_data)


class MessageListSerializer(serializers.ModelSerializer):
    """消息列表序列化器（简化版）"""
    sender_username = serializers.CharField(source='sender.username', read_only=True)
    sender_avatar = serializers.ImageField(source='sender.avatar', read_only=True)
    created_at = serializers.DateTimeField(format="%m-%d %H:%M", read_only=True)
    
    class Meta:
        model = Message
        fields = [
            'id', 'sender_username', 'sender_avatar',
            'content', 'is_read', 'created_at'
        ]